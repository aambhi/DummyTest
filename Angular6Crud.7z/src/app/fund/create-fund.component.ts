import { Component, OnInit } from '@angular/core';
import { SourceSystemModel, CountryModel, CurrencyModel, FundTypeModel, FundStructureTypeModel, WorkFlowModel, FundPartnershipModel } from '../models/master.model';
import { FundService } from './fund.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm, AbstractControl } from '@angular/forms';
import { FundModel } from '../models/fund.model';
import { Router, ActivatedRoute } from '@angular/router';
import { EmptyTextBoxValidator } from '../shared/empty-textbox-validator.directive';
import { isNullOrUndefined } from 'util';
import { dateFormatPipe } from '../shared/date-format.directive';

@Component({
  selector: 'app-create-fund',
  templateUrl: './create-fund.component.html',
  styleUrls: ['./create-fund.component.css']
})
export class CreateFundComponent implements OnInit {
  statusMessage: string = "Loading data. Please wait...";
  datePickerConfig: Partial<BsDatepickerConfig>;
  selectedTypeValue: number = 0;
  _fundform: FormGroup;
  fundid: number = null;

  formSumitAttempt: boolean;
  sourcesystemmaster: SourceSystemModel[];
  countrymaster: CountryModel[];
  fundType: FundTypeModel[];
  currencyMaster: CurrencyModel[];
  fundStructureType: FundStructureTypeModel[];
  fundpartnership: FundPartnershipModel[];

  fatcaWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'US' },
    { Id: 2, Name: 'IGA' },
  ];

  cdotWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'CDOT' },
  ];

  crsWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'CRS Full' },
    { Id: 2, Name: 'CRS Mini' },
  ];

  sponsorEntity: WorkFlowModel[] = [
    { Id: 1, Name: 'Sponsoring Entity' },
    { Id: 2, Name: 'Intermediary' },
  ];

  constructor(private _fundService: FundService, private _formbuilder: FormBuilder, private _router: Router, private _avRoute: ActivatedRoute, private datepipe: dateFormatPipe) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        dateInputFormat: 'DD/MM/YYYY'

      });

    if (this._avRoute.snapshot.params["fundid"]) {
      this.fundid = this._avRoute.snapshot.params["fundid"];
      this._fundService.getFundByFundId(this.fundid)
        .subscribe(
          (data) => {
            this.getFundDetails(this.fundid, data);

          },
          (error) => {
            this.statusMessage = "Problem with the service, please try again later.";
          }
        );
    }

  };

  ngOnInit() {
    this._fundService.getFundMasterData()
      .subscribe(
        (data) => {
          if (data == null) {
            this.statusMessage = "No Records";
          } else {
            this.sourcesystemmaster = data.SingleModel.SourceSystemMaster;
            this.countrymaster = data.SingleModel.CountryMaster;
            this.fundType = data.SingleModel.FundTypeMaster;
            this.currencyMaster = data.SingleModel.CurrencyMaster;
            this.fundStructureType = data.SingleModel.FundStructureTypeMaster;
            this.fundpartnership = data.SingleModel.FundPartnershipMaster;
          }
        },
        (error) => {
          this.statusMessage = "Problem with the service, please try again later.";
        }
      );

    this._fundform = this._formbuilder.group({
      LongName: [null, Validators.required],
      FundCode: [null, Validators.required],
      BaseCYY: ["0", Validators.required],
      FundTypeID: ["0", Validators.required],
      FiscalEndDate: [null],
      Administrator: [null, Validators.required],
      FundNonTaxID: [null],
      FundContactEmail: [null, Validators.pattern("[^ @]*@[^ @]*")],
      SSNCContactEmail: [null, Validators.pattern("[^ @]*@[^ @]*")],
      SourceSystemId: ["0", Validators.required],
      DomicileCountryId: ["0", Validators.required],
      OperationDomicileCountryId: ["0"],
      FundTaxID: [null],
      AuthorizedFromUS: ["false"],
      FundGIIN: [null],
      FundOfFunds: ["false"],
      TakenFATCAService: ["true"],
      TakenCDOTService: ["false"],
      DateOfAARElection: [null],
      FundStructureTypeId: ["0"],
      TemplateTypeId: ["0"],
      CRSTemplateTypeId: [null],
      CDOTTemplateTypeId: ["0"],
      FINumber: [null],
      FundPartnershipId: ["0"],
      AddressInformation: this._formbuilder.group({
        Address1: [null, Validators.required],
        Address2: [null],
        PostCode: [null, Validators.required],
        City: [null, Validators.required],
        AddressCountryId: ["0", Validators.required],
        CountrySubEntity: [null, Validators.required],
      }),
      SponsoringEntity: this._formbuilder.group({
        Type: ["0"],
        NameOrganisation: [null],
        CountrySubEntity: [null],
        TIN: [null],
        SEIssuedById: ["0"],
        SEAddress1: [null],
        SEAddress2: [null],
        SEPostCode: [null],
        SECity: [null],
        ResCountryCodeId: ["0"],
        SECountryCodeId: ["0"],
      })
    });

    this._fundform.patchValue({
      // BaseCYY: 0,
      // FundTypeID: 0,
      // SourceSystemId: 0,
      // DomicileCountryId: 0,
      //AuthorizedFromUS: 'false',
      // FundOfFunds: 'false',
      // TakenFATCAService: 'true',
      // TakenCDOTService: 'false',
      OperationDomicileCountryId: 0,
      FundStructureTypeId: 0,
      TemplateTypeId: 0,
      CRSTemplateTypeId: 0,
      CDOTTemplateTypeId: 0,
      FundPartnershipId: 0,
      AddressInformation: { AddressCountryId: 0 },
      SponsoringEntity: { Type: 0, SEIssuedById: 0, ResCountryCodeId: 0, SECountryCodeId: 0 }
    });
  };

  isFieldValid(field: string) {
    return (
      (!this._fundform.get(field).valid && this._fundform.get(field).touched) ||
      (this._fundform.get(field).untouched && this.formSumitAttempt)
    );
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  saveFundDetails() {
    if (this._fundform.valid) {
      this._fundService.saveFundDetails(this._fundform.value)
        .subscribe((data) => {
          this._router.navigate(['/funddetails']);
        }, error => this.statusMessage = error)
    }
    else {
      this.validateAllFormFields(this._fundform);
    }
  }

  validateSponsorEntity(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      if (field.toString() == 'SponsoringEntity') {
        const sponrctrl = formGroup.get(field);
        if (sponrctrl instanceof FormGroup) {
          Object.keys(sponrctrl.controls).forEach(sponsorfield => {
            const control = sponrctrl.get(sponsorfield);
            if (sponsorfield.toString() == "NameOrganisation" && control.value == null) {
              if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
                this._fundform.valid == false;
              }
            }
          });
        }
      }
    })
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      }
      else if (control instanceof FormGroup)
        this.validateAllFormFields(control);
    });
  }

  reset() {
    this._router.navigate(['/funddetails']);
  }

  onSelectedTypeChange() {
    this.selectedTypeValue = this._fundform.get('SponsoringEntity.Type').value;
  }

  private getFundDetails(fundid: number, data: any) {
    this._fundform.patchValue({
      LongName: data.SingleModel.LongName,
      FundCode: data.SingleModel.FundCode,
      BaseCYY: data.SingleModel.BaseCYY,
      FundTypeID: data.SingleModel.FundTypeID,
      FiscalEndDate:data.SingleModel.FiscalEndDate,
      Administrator: data.SingleModel.Administrator,
      FundNonTaxID: data.SingleModel.FundNonTaxID,
      FundContactEmail: data.SingleModel.FundContactEmail,
      SSNCContactEmail: data.SingleModel.SSNCContactEmail,
      SourceSystemId: data.SingleModel.SourceSystemId,
      DomicileCountryId: data.SingleModel.DomicileCountryId,
      OperationDomicileCountryId: data.SingleModel.OperationDomicileCountryId,
      FundTaxID: data.SingleModel.FundTaxID,
      AuthorizedFromUS: (data.SingleModel.AuthorizedFromUS).toString(),
      FundGIIN: data.SingleModel.FundGIIN,
      FundOfFunds: (data.SingleModel.FundOfFunds).toString(),
      TakenFATCAService: (data.SingleModel.TakenFATCAService).toString(),
      TakenCDOTService: (data.SingleModel.TakenCDOTService).toString(),
      DateOfAARElection: data.SingleModel.DateOfAARElection,
      FundStructureTypeId: data.SingleModel.FundStructureTypeId,
      TemplateTypeId: data.SingleModel.TemplateTypeId,
      CRSTemplateTypeId: data.SingleModel.CRSTemplateTypeId,
      CDOTTemplateTypeId: data.SingleModel.CDOTTemplateTypeId,
      FINumber: data.SingleModel.FINumber,
      FundPartnershipId: data.SingleModel.FundPartnershipId,
      AddressInformation: {
        Address1: data.SingleModel.AddressInformation.Address1,
        Address2: data.SingleModel.AddressInformation.Address2,
        PostCode: data.SingleModel.AddressInformation.PostCode,
        City: data.SingleModel.AddressInformation.City,
        AddressCountryId: data.SingleModel.AddressInformation.AddressCountryId,
        CountrySubEntity: data.SingleModel.AddressInformation.CountrySubEntity,
      },
      SponsoringEntity: {
        Type: data.SingleModel.SponsoringEntity.Type,
        NameOrganisation: data.SingleModel.SponsoringEntity.NameOrganisation,
        CountrySubEntity: data.SingleModel.SponsoringEntity.CountrySubEntity,
        TIN: data.SingleModel.SponsoringEntity.TIN,
        SEIssuedById: data.SingleModel.SponsoringEntity.SEIssuedById,
        SEAddress1: data.SingleModel.SponsoringEntity.SEAddress1,
        SEAddress2: data.SingleModel.SponsoringEntity.SEAddress2,
        SEPostCode: data.SingleModel.SponsoringEntity.SEPostCode,
        SECity: data.SingleModel.SponsoringEntity.SECity,
        ResCountryCodeId: data.SingleModel.SponsoringEntity.ResCountryCodeId,
        SECountryCodeId: data.SingleModel.SponsoringEntity.SECountryCodeId,
      }
    });
    this.selectedTypeValue = data.SingleModel.SponsoringEntity.Type;
  }

}
