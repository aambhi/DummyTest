import { Component, OnInit } from '@angular/core';
import { FundModel } from '../models/fund.model';
import { FundService } from './fund.service';

@Component({
  selector: 'app-list-fund-details',
  templateUrl: './list-fund-details.component.html',
  styleUrls: ['./list-fund-details.component.css']
})
export class ListFundDetailsComponent implements OnInit {
  funds: FundModel[];
  statusMessage: string = "Loading data. Please wait...";
  constructor(private _fundService: FundService) { }

  ngOnInit() {
    //console.log(this._fundService.getFunds());
    this.getFunds();
  };

  getFunds() {
    this._fundService.getFunds()
      .subscribe(
        (funddata) => {
          if (funddata == null) {
            this.statusMessage = "No Records";
          } else {
            this.funds = funddata.ListModel;
            console.log(this.funds);
          }
        },
        (error) => {
          this.statusMessage = "Problem with the service please try after some time";
          console.log(error);
        }
      );
  }

  deleteFund(fundId) {
    console.log(fundId);
    var ans = confirm("Do you want to deactivate fund?");
    if (ans) {
      this._fundService.deleteFund(fundId)
        .subscribe(
          (data) => {
            this.getFunds();
          },
          (error) => {
            this.statusMessage = "Problem with the service please try after some time";
            console.log(error);
          }
        )
    }
  }

}
