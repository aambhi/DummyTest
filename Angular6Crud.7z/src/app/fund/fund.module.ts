import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FundRoutingModule } from './fund-routing.module';
import { CreateFundComponent } from './create-fund.component';
import { ListFundDetailsComponent } from './list-fund-details.component';

@NgModule({
    imports: [
        CommonModule,
        FundRoutingModule,
    ],
    declarations: [CreateFundComponent, ListFundDetailsComponent]
})
export class FundModule { }