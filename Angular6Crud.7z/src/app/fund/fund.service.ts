import { Injectable } from "@angular/core";
import { FundModel } from "../models/fund.model";
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable()
export class FundService {
    headers: Headers;
    options: RequestOptions;

    constructor(private _http: Http) {
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
    }

    getFunds(): Observable<any> {
        return this._http.get('http://localhost:65503/api/fund/GetFunds')
            .pipe(map((response: Response) => <any>response.json()))
            .pipe(catchError(this.handleError));
    }

    getFundMasterData(): Observable<any> {
        return this._http.get('http://localhost:65503/api/fund/GetFundMasterData')
            .pipe(map((response: Response) => <any>response.json()))
            .pipe(catchError(this.handleError));
    }

    saveFundDetails(param: any): Observable<any> {
        let body = JSON.stringify(param);
        return this._http.post('http://localhost:65503/api/fund/SaveFundDetails', body, this.options)
            .pipe(map((response: Response) => <any>response.json()))
            .pipe(catchError(this.handleError));
    }

    deleteFund(fundId : number) {
        return this._http.delete('http://localhost:65503/api/fund/deletefund?fundid='+ fundId, this.options)
            .pipe(map((response: Response) => <any>response.json()))
            .pipe(catchError(this.handleError));
    }

    getFundByFundId(fundId : number) {
        return this._http.get('http://localhost:65503/api/fund/getfundbyfundid?fundid='+ fundId, this.options)
            .pipe(map((response: Response) => <any>response.json()))
            .pipe(catchError(this.handleError));
    }

    private handleError(error: any): Observable<any> {
        return Observable.throw(error.message || error);
    }
}