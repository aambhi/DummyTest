import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../models/employee.model';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {
  private selectedEmployeeId: number;
  @Input() employee: Employee;
  // @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  // handleClick(){
  //   this.notify.emit(this.employee.name);
  // }

  constructor(private _route: ActivatedRoute) { 
    this.selectedEmployeeId =+this._route.snapshot.paramMap.get('id');
  }

  ngOnInit() {
  }

}
