import { Injectable } from "@angular/core";
import { Employee } from "../models/employee.model";

@Injectable()
export class EmployeeService {
    private listEmployees: Employee[] = [
        {
            id: 1,
            name: 'John',
            gender: 'Male',
            contactPreference: 'Email',
            email: 'ambgupta@sscinc.com',
            dateOfBirth: new Date('05/22/1991'),
            isActive: true,
            photoPath: '../assets/images/download.jpg',
            department: '3',
            password: "123456",
            confirmPassword: "123456"
        },
        {
            id: 2,
            name: 'Mary',
            gender: 'Female',
            contactPreference: 'Email',
            email: 'ambguptamary@sscinc.com',
            dateOfBirth: new Date('05/22/1981'),
            isActive: true,
            photoPath: '../assets/images/download3.jpg',
            department: '2',
            password: "123456",
            confirmPassword: "123456"
        },
        {
            id: 3,
            name: 'Mark',
            gender: 'Mmale',
            contactPreference: 'Email',
            email: 'ambguptamark@sscinc.com',
            dateOfBirth: new Date('10/22/1999'),
            isActive: true,
            photoPath: '../assets/images/download2.jpg',
            department: '1',
            password: "123456",
            confirmPassword: "123456"
        }
    ];

    getEmployees(): Employee[] {
        return this.listEmployees;
    }

    saveEmployee(employee: Employee) {
        this.listEmployees.push(employee);
    }

    getEmployee(employeeId: number): Employee {
        return this.listEmployees.find(e => e.id === employeeId);
    }
}