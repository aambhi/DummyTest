import { Validators, FormControl, ValidatorFn, AbstractControl } from "@angular/forms";

export class EmptyTextBoxValidator extends Validators {
    static validateEMptyControl(sponsorType: number): ValidatorFn {
        return (control: AbstractControl): { [key: string]: boolean } | null => {
            if (sponsorType == 1 || sponsorType == 2) {
                if (control.value == null || control.value == "") {
                    return { "required": true };
                }
            }
            return null;
        }
    };
}
