import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blankform',
  templateUrl: './blankform.component.html',
  styleUrls: ['./blankform.component.css']
})
export class BlankformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
