export class SourceSystemModel {
    SourceSystemId: number;
    SourceSystemName: string;
}

export class CountryModel {
    CountryId: number;
    CountryName: string;
}

export class FundTypeModel {
    Id: number;
    Name: string;
}

export class CurrencyModel {
    Id: number;
    Currency: string;
}

export class FundStructureTypeModel {
    Id: number;
    Name: string;
}

export class WorkFlowModel{
    Id: number;
    Name: string; 
}

export class FundPartnershipModel{
    Id: number;
    Description: string; 
}