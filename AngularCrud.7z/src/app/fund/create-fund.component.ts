import { Component, OnInit } from '@angular/core';
import { SourceSystemModel, CountryModel, CurrencyModel, FundTypeModel, FundStructureTypeModel, WorkFlowModel, FundPartnershipModel } from '../models/master.model';
import { FundService } from './fund.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm } from '@angular/forms';
import { FundModel } from '../models/fund.model';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-create-fund',
  templateUrl: './create-fund.component.html',
  styleUrls: ['./create-fund.component.css']
})
export class CreateFundComponent implements OnInit {
  statusMessage: string = "Loading data. Please wait...";
  datePickerConfig: Partial<BsDatepickerConfig>;

  _fundform: FormGroup;
  private formSumitAttempt: boolean;

  sourcesystemmaster: SourceSystemModel[];
  countrymaster: CountryModel[];
  fundType: FundTypeModel[];
  currencyMaster: CurrencyModel[];
  fundStructureType: FundStructureTypeModel[];
  fundpartnership: FundPartnershipModel[];

  fatcaWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'US' },
    { Id: 2, Name: 'IGA' },
  ];

  cdotWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'CDOT' },
  ];

  crsWorkFlow: WorkFlowModel[] = [
    { Id: 1, Name: 'CRS Full' },
    { Id: 2, Name: 'CRS Mini' },
  ];

  sponsorEntity: WorkFlowModel[] = [
    { Id: 1, Name: 'Sponsoring Entity' },
    { Id: 2, Name: 'Intermediary' },
  ];

  constructor(private _fundService: FundService, private _formbuilder: FormBuilder, private _router: Router, private _avRoute: ActivatedRoute) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        dateInputFormat: 'DD/MM/YYYY'

      });

    this._fundform = this._formbuilder.group({
      LongName: [null, Validators.required],
      FundCode: [null, Validators.required],
      BaseCYY: [null, Validators.required],
      FundTypeID: [null, Validators.required],
      FiscalEndDate: [null],
      Administrator: [null, Validators.required],
      FundNonTaxID: [null],
      FundContactEmail: [null, Validators.pattern("[^ @]*@[^ @]*")],
      SSNCContactEmail: [null, Validators.pattern("[^ @]*@[^ @]*")],
      SourceSystemId: [null, Validators.required],
      DomicileCountryId: [null, Validators.required],
      OperationDomicileCountryId: [null],
      FundTaxID: [null],
      AuthorizedFromUS: [null],
      FundGIIN: [null],
      FundOfFunds: [null],
      TakenFATCAService: [null],
      TakenCDOTService: [null],
      DateOfAARElection: [null],
      FundStructureTypeId: [null],
      TemplateTypeId: [null],
      CRSTemplateTypeId: [null],
      CDOTTemplateTypeId: [null],
      FINumber: [null],
      FundPartnershipId: [null],
      AddressInformation: this._formbuilder.group({
        Address1: [null, Validators.required],
        Address2: [null],
        PostCode: [null, Validators.required],
        City: [null, Validators.required],
        AddressCountryId: [null, Validators.required],
        CountrySubEntity: [null, Validators.required],
      }),
      SponsoringEntity: this._formbuilder.group({
        Type: [null],
        NameOrganisation: [null, Validators.required],
        CountrySubEntity: [null, Validators.required],
        TIN: [null, Validators.required],
        SEIssuedById: [null, Validators.required],
        SEAddress1: [null, Validators.required],
        SEAddress2: [null],
        SEPostCode: [null, Validators.required],
        SECity: [null, Validators.required],
        ResCountryCodeId: [null, Validators.required],
        SECountryCodeId: [null, Validators.required],
      }),
    });
  };

  ngOnInit() {
    this._fundService.getFundMasterData()
      .subscribe(
        (data) => {
          if (data == null) {
            this.statusMessage = "No Records";
          } else {
            this.sourcesystemmaster = data.SingleModel.SourceSystemMaster;
            this.countrymaster = data.SingleModel.CountryMaster;
            this.fundType = data.SingleModel.FundTypeMaster;
            this.currencyMaster = data.SingleModel.CurrencyMaster;
            this.fundStructureType = data.SingleModel.FundStructureTypeMaster;
            this.fundpartnership = data.SingleModel.FundPartnershipMaster;
          }
        },
        (error) => {
          this.statusMessage = "Problem with the service, please try again later.";
        }
      );

    this._fundform.controls['BaseCYY'].setValue('0', { onlySelf: true });
    this._fundform.controls['FundTypeID'].setValue('0', { onlySelf: true });
    this._fundform.controls['SourceSystemId'].setValue('0', { onlySelf: true });
    this._fundform.controls['DomicileCountryId'].setValue('0', { onlySelf: true });

    this._fundform.get('AddressInformation.AddressCountryId').setValue('0');
    this._fundform.get('SponsoringEntity.Type').setValue('0');
    this._fundform.get('SponsoringEntity.SEIssuedById').setValue('0');
    this._fundform.get('SponsoringEntity.ResCountryCodeId').setValue('0');
    this._fundform.get('SponsoringEntity.SECountryCodeId').setValue('0');

    this._fundform.patchValue({
      AuthorizedFromUS: 'false',
      FundOfFunds: 'false',
      TakenFATCAService: 'true',
      TakenCDOTService: 'false',
      OperationDomicileCountryId: 0,
      FundStructureTypeId: 0,
      TemplateTypeId: 0,
      CRSTemplateTypeId: 0,
      CDOTTemplateTypeId: 0,
      FundPartnershipId: 0,
    });
  };

  isFieldValid(field: string) {
    return (
      (!this._fundform.get(field).valid && this._fundform.get(field).touched) ||
      (this._fundform.get(field).untouched && this.formSumitAttempt)
    );
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  saveFundDetails() {
    if (this._fundform.valid) {
      this._fundService.saveFundDetails(this._fundform.value)
        .subscribe((data) => {
          this._router.navigate(['/funddetails']);
        }, error => this.statusMessage = error)
    } else {
      this.validateAllFormFields(this._fundform);
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  reset() {
    this._router.navigate(['/funddetails']);
  }

}
