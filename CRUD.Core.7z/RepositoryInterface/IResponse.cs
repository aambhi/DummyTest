﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.Core.RepositoryInterface
{
    public interface IResponse<TModel>
    {
        String Message { get; set; }

        Boolean DidError { get; set; }

        String ErrorMessage { get; set; }

        IEnumerable<TModel> ListModel { get; set; }

        TModel SingleModel { get; set; }
    }
}
