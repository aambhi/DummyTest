﻿using CRUD.Core.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.Core.RepositoryInterface
{
    public interface IFundRepository
    {
        Task<List<IEnumerable>> GetFundMasterData();

        Task<List<FundModel>> GetFunds();
    }
}
