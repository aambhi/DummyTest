﻿namespace CRUD.Core.Models
{
    public class SourceSystemModel
    {
        public int SourceSystemId { get; set; }
        public string SourceSystemCode { get; set; }
        public string SourceSystemName { get; set; }
        public string ExternalSourceSystemId { get; set; }
        public string Note { get; set; }
    }
    public class FundTypeModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class CountryModel
    {
        public int CountryID { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string CountryInvestorGroup { get; set; }
        public bool? ISCDOT { get; set; }
        public bool? IsCRS { get; set; }
        public int? Isocode { get; set; }
    }

    public class CurrencyModel
    {
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
    }

    public class FundStructureTypeModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class FundPartnershipModel
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
