﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUD.Core.Models
{
    public class FundModel
    {
        public int FundId { get; set; }
        public int SourceSystemId { get; set; }
        public string LongName { get; set; }
        public string ShortName { get; set; }
        public int DomicileCountryId { get; set; }
        public int? OperationDomicileCountryId { get; set; }
        public string FundCode { get; set; }
        public int ClientId { get; set; }
        public int? FundTypeID { get; set; }
        public string BaseCYY { get; set; }
        public DateTime? FiscalEndDate { get; set; }
        public string Administrator { get; set; }
        public bool? FundOfFunds { get; set; }
        public string FundContactEmail { get; set; }
        public string SSNCContactEmail { get; set; }
        public DateTime? DeactiveDate { get; set; }
        public string FundTaxID { get; set; }
        public string FundNonTaxID { get; set; }
        public bool TakenFATCAService { get; set; }
        public bool TakenCDOTService { get; set; }
        public bool AuthorizedFromUS { get; set; }
        public string FundGIIN { get; set; }
        public string Updateby { get; set; }
        public DateTime? Updateon { get; set; }
        public bool IsIRSMatch { get; set; }
        public int FundStructureTypeId { get; set; }
        public int? ParentFundId { get; set; }
        public bool IsIRSFundNameMatch { get; set; }
        public string UmbrellaFundGIIN { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? OverrideReason { get; set; }
        public int? TemplateTypeId { get; set; }
        public DateTime? ActiveDate { get; set; }
        public int? CDOTTemplateTypeId { get; set; }
        public int? CRSTemplateTypeId { get; set; }
        public string FINumber { get; set; }
        public bool? IsAutoAnswer { get; set; }
        public int? FundPartnershipId { get; set; }
        public DateTime? StartServiceDate { get; set; }
        public DateTime? DateOfAARElection { get; set; }

        public AddressInformationModel AddressInformation { get; set; }
        public SponsorEntityModel SponsoringEntity { get; set; }
    }

    public class SponsorEntityModel
    {
        public string Type { get; set; }
        public string NameOrganisation { get; set; }
        public string TIN { get; set; }
        public string SEAddress1 { get; set; }
        public string SEAddress2 { get; set; }
        public string SEPostCode { get; set; }
        public string SECity { get; set; }
        public int? ResCountryCodeId { get; set; }
        public int? SECountryCodeId { get; set; }
        public string ResCountryCode { get; set; }
        public string SECountryCode { get; set; }
        public string SEIssuedBy { get; set; }
        public string CountrySubEntity { get; set; }
        public int? SEIssuedById { get; set; }
    }

    public class AddressInformationModel
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string PostCode { get; set; }
        public string City { get; set; }
        public int? AddressCountryId { get; set; }
        public string AddressCountry { get; set; }
        public string CountrySubEntity { get; set; }
    }
}
