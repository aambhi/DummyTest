﻿using CRUD.Core.Models;
using CRUD.Core.RepositoryInterface;
using CRUD.Data.Data;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Linq;
using CRUD.Data.Utilities;
using System.Collections;

namespace AngularCrud.Data.Repositories
{
    public class FundRepository : IFundRepository
    {
        private readonly TestDBEntities dbContext;

        public FundRepository(TestDBEntities _dbContext)
        {
            dbContext = _dbContext;
        }

        public async Task<List<IEnumerable>> GetFundMasterData()
        {
            var res = await dbContext.MultipleResults("[dbo].[GetMasterDataForFund]")
                .With<SourceSystemModel>()
                .With<CountryModel>()
                .With<FundTypeModel>()
                .With<CurrencyModel>()
                .With<FundStructureTypeModel>()
                .With<FundPartnershipModel>()
                .Execute();

            return res;
        }

        public async Task<List<FundModel>> GetFunds()
        {
            var result = await dbContext.Funds.ToListAsync();
            return result.Select(data => new FundModel
            {
                LongName = data.LongName,
                FundCode = data.FundCode
            }).ToList();
        }
    }
}
